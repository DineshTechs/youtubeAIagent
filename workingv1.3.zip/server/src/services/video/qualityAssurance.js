import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';
import ffmpegStatic from 'ffmpeg-static';
import {env} from '../../config/env.js';

const ffmpegPath = env.ffmpegPath || ffmpegStatic || 'ffmpeg';
function runFfmpeg(args){
  return new Promise((resolve,reject)=>{
    const child=spawn(ffmpegPath,args,{stdio:['ignore','ignore','pipe']});
    let stderr='';
    child.stderr.on('data',chunk=>{stderr+=chunk.toString();if(stderr.length>2_000_000)stderr=stderr.slice(-1_000_000);});
    child.on('error',error=>reject(new Error(`Unable to start FFmpeg QA: ${error.message}`)));
    child.on('close',code=>code===0?resolve(stderr):reject(new Error(`FFmpeg QA decode failed (${code}): ${stderr.slice(-2500)}`)));
  });
}
function check(name,status,message,details={}){return {name,status,message,...details};}
function seconds(value){const p=String(value||'').trim().split(':').map(Number);return p.length===3&&p.every(Number.isFinite)?p[0]*3600+p[1]*60+p[2]:null;}
function matches(output,pattern){return [...output.matchAll(pattern)].map(m=>Number(m[1])).filter(Number.isFinite);}
function sumSegments(starts,ends){let total=0;for(let i=0;i<Math.min(starts.length,ends.length);i++)total+=Math.max(0,ends[i]-starts[i]);return total;}

export async function runVideoQualityAssurance({videoPath,expectedWidth=1080,expectedHeight=1920,scenePaths=[],audioPath,subtitlePath,expectedDurationSec,expectedSceneCount}={}){
  const checks=[];
  if(!videoPath){checks.push(check('Rendered file','FAIL','No rendered MP4 path was supplied.'));return report(checks);}
  let stat;
  try{stat=await fs.stat(videoPath);}catch{checks.push(check('Rendered file','FAIL','Final MP4 is missing.',{videoPath}));return report(checks);}
  const fileOk=stat.isFile()&&stat.size>=1000;
  checks.push(check('Rendered file',fileOk?'PASS':'FAIL',fileOk?'MP4 exists and has a plausible file size.':'MP4 is not a regular file or is unexpectedly small.',{sizeBytes:stat.size,extension:path.extname(videoPath).toLowerCase()}));
  if(!fileOk)return report(checks,{sizeBytes:stat.size});

  let output='';
  try{output=await runFfmpeg(['-hide_banner','-i',videoPath,'-map','0:v:0','-map','0:a:0?','-vf','blackdetect=d=1:pix_th=0.10','-f','null','-']);
    if(/Stream #\d+:\d+(?:\([^)]+\))?.*?Audio:/i.test(output)){
      output+='\n'+await runFfmpeg(['-hide_banner','-i',videoPath,'-map','0:a:0','-af','silencedetect=noise=-45dB:d=1','-f','null','-']);
    }}
  catch(error){checks.push(check('Full decode','FAIL','FFmpeg could not decode the complete MP4 video/audio streams.',{details:error.message}));return report(checks,{sizeBytes:stat.size});}
  checks.push(check('Full decode','PASS','FFmpeg decoded the complete mapped video and available audio streams.'));

  const dm=output.match(/Duration:\s*(\d{2}:\d{2}:\d{2}(?:\.\d+)?)/i);
  const durationSec=dm?seconds(dm[1]):null;
  const vm=output.match(/Stream #\d+:\d+(?:\([^)]+\))?.*?Video:\s*([^\n]+)/i);
  const am=output.match(/Stream #\d+:\d+(?:\([^)]+\))?.*?Audio:\s*([^\n]+)/i);
  const dimensions=vm?.[1]?.match(/(?:,|\s)(\d{2,5})x(\d{2,5})(?:[,\s]|$)/);
  const width=dimensions?Number(dimensions[1]):null,height=dimensions?Number(dimensions[2]):null;
  checks.push(check('Video stream',vm?'PASS':'FAIL',vm?'Video stream detected.':'No video stream detected.'));
  checks.push(check('Audio stream',am?'PASS':'FAIL',am?'Narration/audio stream detected.':'No audio stream detected.'));
  if(width&&height){
    const portrait=height>width,aspect=Math.abs(width/height-9/16)<.025,resolution=width>=720&&height>=1280;
    checks.push(check('Portrait format',portrait&&aspect?'PASS':'FAIL',portrait&&aspect?'Portrait 9:16 aspect ratio confirmed.':`Expected 9:16 portrait; found ${width}x${height}.`,{width,height,aspectRatio:Number((width/height).toFixed(4))}));
    checks.push(check('Resolution',resolution?'PASS':'WARN',resolution?`Resolution ${width}x${height} is suitable for Shorts.`:`Resolution ${width}x${height} is below 720x1280.`,{width,height,expectedWidth,expectedHeight}));
  }else checks.push(check('Video metadata','FAIL','FFmpeg could not determine the rendered video dimensions.'));
  if(durationSec!=null){
    const valid=durationSec>0&&durationSec<=180;
    checks.push(check('Short duration',valid?'PASS':'WARN',valid?`Duration ${durationSec.toFixed(1)} seconds is within the 3-minute Shorts limit.`:`Duration is ${durationSec.toFixed(1)} seconds; verify intended Shorts format.`,{durationSec}));
    if(Number(expectedDurationSec)>0){const delta=Math.abs(durationSec-Number(expectedDurationSec)),tol=Math.max(1,Number(expectedDurationSec)*.08);checks.push(check('Expected duration match',delta<=tol?'PASS':'WARN',delta<=tol?'Rendered duration is close to the expected duration.':`Rendered duration differs from expected by ${delta.toFixed(1)} seconds.`,{expectedDurationSec:Number(expectedDurationSec),actualDurationSec:durationSec,differenceSec:Number((durationSec-Number(expectedDurationSec)).toFixed(2)),toleranceSec:Number(tol.toFixed(2))}));}
  }else checks.push(check('Duration metadata','WARN','FFmpeg did not expose a readable MP4 duration.'));

  const blackStarts=matches(output,/black_start:\s*([\d.]+)/g),blackEnds=matches(output,/black_end:\s*([\d.]+)/g),blackDuration=sumSegments(blackStarts,blackEnds);
  const blackWarn=blackDuration>Math.max(2,(durationSec||0)*.08);
  checks.push(check('Black-frame scan',blackWarn?'WARN':'PASS',blackWarn?`Detected approximately ${blackDuration.toFixed(1)} seconds of black frames; review the video.`:'No prolonged black-frame segments detected.',{blackDurationSec:Number(blackDuration.toFixed(2)),segments:blackStarts.length}));
  const silenceStarts=matches(output,/silence_start:\s*([\d.]+)/g),silenceEnds=matches(output,/silence_end:\s*([\d.]+)/g),silenceDuration=sumSegments(silenceStarts,silenceEnds);
  const silenceWarn=silenceDuration>Math.max(2,(durationSec||0)*.08);
  checks.push(check('Audio silence scan',silenceWarn?'WARN':'PASS',silenceWarn?`Detected approximately ${silenceDuration.toFixed(1)} seconds of silence; check narration gaps.`:'No prolonged audio-silence segments detected.',{silenceDurationSec:Number(silenceDuration.toFixed(2)),segments:silenceStarts.length}));

  const scenes=Array.isArray(scenePaths)?scenePaths:[];let validScenes=0;const sceneDetails=[];
  for(let i=0;i<scenes.length;i++){try{const s=await fs.stat(scenes[i]);const valid=s.isFile()&&s.size>100;if(valid)validScenes++;sceneDetails.push({scene:i+1,exists:true,sizeBytes:s.size,valid,fileName:path.basename(scenes[i])});}catch{sceneDetails.push({scene:i+1,exists:false,valid:false,fileName:scenes[i]?path.basename(scenes[i]):null});}}
  const countOk=Number(expectedSceneCount)>0?scenes.length===Number(expectedSceneCount):scenes.length>0,scenesOk=countOk&&validScenes===scenes.length;
  checks.push(check('Scene assets',scenesOk?'PASS':'FAIL',scenes.length?`${validScenes}/${scenes.length} scene image assets are present and non-empty${Number(expectedSceneCount)>0?`; expected ${expectedSceneCount}`:''}.`:'No scene image assets were supplied.',{validScenes,totalScenes:scenes.length,expectedSceneCount:Number(expectedSceneCount)||null,scenes:sceneDetails}));
  if(audioPath){try{const a=await fs.stat(audioPath);checks.push(check('Narration source',a.isFile()&&a.size>100?'PASS':'FAIL',a.size>100?'Narration source file is present.':'Narration source file is empty or too small.',{sizeBytes:a.size,fileName:path.basename(audioPath)}));}catch{checks.push(check('Narration source','WARN','Separate narration source file is missing.',{fileName:path.basename(audioPath)}));}}
  else checks.push(check('Narration source','WARN','No separate narration source path was supplied; rendered audio stream was checked instead.'));
  if(subtitlePath){try{const s=await fs.stat(subtitlePath);checks.push(check('Subtitle file',s.isFile()&&s.size>0?'PASS':'WARN',s.size>0?'Subtitle sidecar file exists.':'Subtitle sidecar file is empty.',{sizeBytes:s.size,fileName:path.basename(subtitlePath)}));}catch{checks.push(check('Subtitle file','WARN','Subtitle sidecar file is missing; burned-in captions require visual review.',{fileName:path.basename(subtitlePath)}));}}
  else checks.push(check('Subtitle file','REVIEW','No subtitle sidecar supplied; if captions are burned in, verify them in the visual review.'));
  checks.push(check('Visual relevance','REVIEW','Human review required: confirm every image matches its narration and characters remain consistent.'));
  checks.push(check('Subtitle appearance','REVIEW','Human review required: confirm captions are readable, correctly positioned and do not obscure important action.'));
  checks.push(check('Story suitability','REVIEW','Human review required: check age suitability, story clarity and originality.'));
  return report(checks,{durationSec,width,height,sizeBytes:stat.size,videoPath,ffmpegPath:path.basename(ffmpegPath)});
}
function report(checks,meta={}){const failures=checks.filter(x=>x.status==='FAIL').length,warnings=checks.filter(x=>x.status==='WARN').length,passed=checks.filter(x=>x.status==='PASS').length,score=Math.max(0,Math.round(passed/(passed+warnings+failures||1)*100));return {version:'1.3',pass:failures===0,score,summary:{passed,warnings,failures,manualReviews:checks.filter(x=>x.status==='REVIEW').length},checks,meta,ranAt:new Date()};}
