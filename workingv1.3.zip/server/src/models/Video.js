import mongoose from 'mongoose';
const schema = new mongoose.Schema({
  storyId:{type:mongoose.Schema.Types.ObjectId,ref:'Story'}, title:String,
  status:{type:String,enum:['QUEUED','PLANNED','SCRIPT_GENERATED','SCRIPT_QA','ASSETS_GENERATING','VIDEO_RENDERING','VIDEO_QA','AWAITING_APPROVAL','APPROVED','UPLOADING','SCHEDULED','PUBLISHED','FAILED','CANCELLED'],default:'PLANNED'},
  statusHistory:[{status:String,at:{type:Date,default:Date.now},message:String,attempt:{type:Number,default:0},source:{type:String,default:'VIDEO'}}],
  durationSec:Number, renderPath:String, thumbnailPath:String, youtubeVideoId:String, scheduledAt:Date,
  mediaAssetDetails:[{sceneNumber:Number,path:String,mode:String,sizeBytes:Number,valid:Boolean,generatedAt:Date,reused:Boolean,prompt:String}],
  qa:mongoose.Schema.Types.Mixed, visualReview:{imagesMatch:Boolean,subtitlesReadable:Boolean,ageAppropriate:Boolean,reviewedAt:Date}, media:{scenes:[String],audio:String,subtitles:String}, error:String
},{timestamps:true});
export default mongoose.model('Video',schema);
