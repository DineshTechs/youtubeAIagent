# Scene asset regeneration fix

This patch fixes resumed/new video jobs where a saved video/story exists but a physical scene image is missing.

Behavior:
- Missing `scene-XX.png` is regenerated automatically.
- A stale/missing asset is never marked completed.
- The selected Settings image provider is passed explicitly to image generation.
- Pipeline trace records provider, model, requested output and regeneration state.
- If a provider returns a different output path, it is normalized to the canonical scene filename.
- The DB-selected media provider is authoritative in `getAISettings()`; env values are defaults only.

Restart the backend after applying the patch.
