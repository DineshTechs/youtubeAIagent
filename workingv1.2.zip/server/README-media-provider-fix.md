# Media provider selection fix

This patch fixes stale Mock/Development selection and invalid mock assets.

- If `MEDIA_IMAGE_PROVIDER` or `IMAGE_PROVIDER` is explicitly set, it is authoritative for generation.
- Otherwise the database Settings selection is authoritative.
- Mock provider now uses SVG output/validation even when MEDIA_MOCK=false.
- Pipeline logs show provider and selection source.

For Cloudflare, set `MEDIA_IMAGE_PROVIDER=cloudflare` and restart the backend, or select Cloudflare in Settings when no explicit env provider is set.
