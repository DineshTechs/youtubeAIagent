# Scene narration render fix

The narration stage was correctly generating and validating per-scene audio, but the worker was not passing `sceneAudioFiles` and `sceneDurations` into `renderVideo()`.

The renderer therefore received `undefined` and reported:

`Scene narration audio set is incomplete (0/N).`

The worker now passes both arrays to the renderer and includes them in the FFMPEG_RENDER pipeline trace.
