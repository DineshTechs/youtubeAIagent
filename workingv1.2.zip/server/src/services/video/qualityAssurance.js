import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';
import ffmpegStatic from 'ffmpeg-static';
import {env} from '../../config/env.js';

const ffmpegPath = env.ffmpegPath || ffmpegStatic || 'ffmpeg';

function runFfmpeg(args){
  return new Promise((resolve,reject)=>{
    const child=spawn(ffmpegPath,args,{stdio:['ignore','ignore','pipe']});
    let stderr='';
    child.stderr.on('data',chunk=>{stderr+=chunk.toString(); if(stderr.length>2_000_000) stderr=stderr.slice(-1_000_000);});
    child.on('error',error=>reject(new Error(`Unable to start FFmpeg QA: ${error.message}`)));
    child.on('close',code=>code===0?resolve(stderr):reject(new Error(`FFmpeg QA decode failed (${code}): ${stderr.slice(-2500)}`)));
  });
}

function check(name,status,message,details={}){return {name,status,message,...details};}

function seconds(value){
  const parts=String(value||'').trim().split(':').map(Number);
  if(parts.length!==3||parts.some(n=>!Number.isFinite(n))) return null;
  return parts[0]*3600+parts[1]*60+parts[2];
}

export async function runVideoQualityAssurance({videoPath,expectedWidth=1080,expectedHeight=1920,scenePaths=[],audioPath,subtitlePath,expectedDurationSec}={}){
  const checks=[];
  let stat;
  try{stat=await fs.stat(videoPath);}catch{checks.push(check('Rendered file','FAIL','Final MP4 is missing.')); return report(checks);}
  checks.push(check('Rendered file',stat.isFile()&&stat.size>=1000?'PASS':'FAIL',stat.size>=1000?'MP4 exists and has a plausible file size.':'MP4 is unexpectedly small.',{sizeBytes:stat.size}));
  if(stat.size<1000) return report(checks);

  let output='';
  try{
    output=await runFfmpeg([
      '-hide_banner','-i',videoPath,
      '-vf','blackdetect=d=1:pix_th=0.10',
      '-af','silencedetect=noise=-45dB:d=1',
      '-f','null','-'
    ]);
  }catch(error){
    checks.push(check('Full decode','FAIL','FFmpeg could not decode the complete MP4.',{details:error.message}));
    return report(checks);
  }
  checks.push(check('Full decode','PASS','FFmpeg decoded the complete video and audio streams.'));

  const durationMatch=output.match(/Duration:\s*(\d{2}:\d{2}:\d{2}(?:\.\d+)?)/i);
  const durationSec=durationMatch?seconds(durationMatch[1]):Number(expectedDurationSec)||null;
  const videoMatch=output.match(/Video:\s*[^\n]*?(\d{2,5})x(\d{2,5})/i);
  const width=videoMatch?Number(videoMatch[1]):null;
  const height=videoMatch?Number(videoMatch[2]):null;
  const hasAudio=/Audio:/i.test(output);
  const hasVideo=/Video:/i.test(output);

  checks.push(check('Video stream',hasVideo?'PASS':'FAIL',hasVideo?'Video stream detected.':'No video stream detected.'));
  checks.push(check('Audio stream',hasAudio?'PASS':'FAIL',hasAudio?'Narration audio stream detected.':'No audio stream detected.'));
  if(width&&height){
    const isPortrait=height>width;
    const aspectOk=Math.abs((width/height)-(9/16))<0.025;
    const sizeOk=width>=720&&height>=1280;
    checks.push(check('Portrait format',isPortrait&&aspectOk?'PASS':'FAIL',isPortrait&&aspectOk?'Portrait 9:16 aspect ratio confirmed.':`Expected 9:16 portrait; found ${width}x${height}.`,{width,height,aspectRatio:Number((width/height).toFixed(4))}));
    checks.push(check('Resolution',sizeOk?'PASS':'WARN',sizeOk?`Resolution ${width}x${height} is suitable for Shorts.`:`Resolution ${width}x${height} is below 720x1280.`,{width,height,expectedWidth,expectedHeight}));
  }else checks.push(check('Video metadata','WARN','FFmpeg did not expose video dimensions in its diagnostic output.'));

  if(durationSec!=null){
    const durationOk=durationSec>0&&durationSec<=180;
    checks.push(check('Short duration',durationOk?'PASS':'WARN',durationOk?`Duration ${durationSec.toFixed(1)} seconds is within the 3-minute Shorts limit.`:`Duration is ${durationSec.toFixed(1)} seconds; verify current Shorts eligibility and intended format.`,{durationSec}));
    if(expectedDurationSec&&Math.abs(durationSec-expectedDurationSec)>Math.max(1,expectedDurationSec*.08)) checks.push(check('Narration duration match','WARN',`Rendered duration differs from expected narration by ${(durationSec-expectedDurationSec).toFixed(1)} seconds.`,{expectedDurationSec,actualDurationSec:durationSec}));
  }

  const blackStarts=[...output.matchAll(/black_start:\s*([\d.]+)/g)].map(m=>Number(m[1]));
  const blackEnds=[...output.matchAll(/black_end:\s*([\d.]+)/g)].map(m=>Number(m[1]));
  let blackDuration=0;
  for(let i=0;i<Math.min(blackStarts.length,blackEnds.length);i++) blackDuration+=Math.max(0,blackEnds[i]-blackStarts[i]);
  const blackWarn=blackDuration>Math.max(2,(durationSec||0)*.08);
  checks.push(check('Black-frame scan',blackWarn?'WARN':'PASS',blackWarn?`Detected approximately ${blackDuration.toFixed(1)} seconds of black frames; review the video.`:'No prolonged black-frame segments detected.',{blackDurationSec:Number(blackDuration.toFixed(2)),segments:blackStarts.length}));

  const silenceStarts=[...output.matchAll(/silence_start:\s*([\d.]+)/g)].map(m=>Number(m[1]));
  const silenceEnds=[...output.matchAll(/silence_end:\s*([\d.]+)/g)].map(m=>Number(m[1]));
  let silenceDuration=0;
  for(let i=0;i<Math.min(silenceStarts.length,silenceEnds.length);i++) silenceDuration+=Math.max(0,silenceEnds[i]-silenceStarts[i]);
  const silenceWarn=silenceDuration>Math.max(2,(durationSec||0)*.08);
  checks.push(check('Audio silence scan',silenceWarn?'WARN':'PASS',silenceWarn?`Detected approximately ${silenceDuration.toFixed(1)} seconds of silence; check narration gaps.`:'No prolonged audio-silence segments detected.',{silenceDurationSec:Number(silenceDuration.toFixed(2)),segments:silenceStarts.length}));

  const existingScenes=Array.isArray(scenePaths)?scenePaths:[];
  let validScenes=0;
  for(const scenePath of existingScenes){try{const s=await fs.stat(scenePath);if(s.isFile()&&s.size>100)validScenes++;}catch{}}
  checks.push(check('Scene assets',existingScenes.length>0&&validScenes===existingScenes.length?'PASS':'FAIL',existingScenes.length?`${validScenes}/${existingScenes.length} scene image assets are present.`:'No scene image assets were supplied.',{validScenes,totalScenes:existingScenes.length}));

  if(audioPath){try{const a=await fs.stat(audioPath);checks.push(check('Narration source',a.size>100?'PASS':'WARN',a.size>100?'Narration source file is present.':'Narration source file is empty or very small.',{sizeBytes:a.size}));}catch{checks.push(check('Narration source','WARN','Separate narration source file is missing.'));}}
  if(subtitlePath){try{const s=await fs.stat(subtitlePath);checks.push(check('Subtitle file',s.size>0?'PASS':'WARN',s.size>0?'Subtitle file exists.':'Subtitle file is empty.',{sizeBytes:s.size}));}catch{checks.push(check('Subtitle file','WARN','Subtitle sidecar file is missing; burned-in captions require visual review.'));}}
  checks.push(check('Visual relevance','REVIEW','Human review required: confirm every image matches its narration and characters remain consistent.'));
  checks.push(check('Subtitle appearance','REVIEW','Human review required: confirm captions are readable, correctly positioned and do not obscure important action.'));
  checks.push(check('Story suitability','REVIEW','Human review required: check age suitability, story clarity and originality.'));
  return report(checks,{durationSec,width,height,sizeBytes:stat.size,ffmpegPath:path.basename(ffmpegPath)});
}

function report(checks,meta={}){
  const failures=checks.filter(x=>x.status==='FAIL').length;
  const warnings=checks.filter(x=>x.status==='WARN').length;
  const passed=checks.filter(x=>x.status==='PASS').length;
  const score=Math.max(0,Math.round((passed/(passed+warnings+failures||1))*100));
  return {version:'1.2',pass:failures===0,score,summary:{passed,warnings,failures,manualReviews:checks.filter(x=>x.status==='REVIEW').length},checks,meta,ranAt:new Date()};
}
