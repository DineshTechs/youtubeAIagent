# FFmpeg ENOENT fix

The narration pipeline was calling `spawn('ffmpeg', ...)`, which fails with `ENOENT` when FFmpeg is not on the Windows PATH.

This patch uses the project's installed `ffmpeg-static` binary first and falls back to `ffmpeg` only if necessary.

After applying, run `npm install` in `server` if dependencies are not installed, then restart the backend.
