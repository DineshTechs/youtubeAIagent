# Cloudflare provider enforcement fix

The selected image provider is passed explicitly from the generation worker to the image service, preventing a stale/default OpenAI provider from being used. Replace the listed files and restart the backend.
