# Per-scene TTS synchronization

Narration is generated separately for each scene. The worker measures the actual audio duration with FFmpeg, writes it to `story.scenes[].durationSec`, and passes those exact durations plus per-scene audio files to the renderer. Each visual scene therefore lasts exactly as long as its narration. Pipeline trace contains `SCENE_N_VOICE` and `FFMPEG_RENDER` timing data. Restart the backend after replacing these files.
