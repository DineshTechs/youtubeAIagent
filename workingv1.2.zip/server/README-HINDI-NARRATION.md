# Hindi narration support

This server patch adds Hindi-aware narration generation to the existing TTS pipeline.

## What changed

- Hindi/hi-IN/Hindi-language labels are detected from the series language passed by the worker.
- OpenAI TTS uses a native Indian Hindi accent and Devanagari pronunciation instruction when the selected model is `gpt-4o-mini-tts`.
- The narration prompt explicitly tells the voice not to translate, paraphrase, omit, or add words.
- Accent, delivery style, and speaking speed are stored in MongoDB AI settings and exposed by `GET /api/ai/settings`.
- Existing settings are migrated automatically when the server reads global AI settings.
- Groq Orpheus is identified as English-only. If Hindi is requested while Groq is selected, generation stops with a clear settings instruction instead of generating poor English-accented Hindi.
- No image providers or image-generation behavior were changed.

## Required settings for Hindi

1. Set the series language to `Hindi` (or `hi-IN`).
2. In AI Settings → Narration, select **OpenAI TTS**.
3. Set the model to **`gpt-4o-mini-tts`**.
4. Choose an OpenAI voice. The supported voice IDs may include `coral`, `nova`, `shimmer`, `marin`, `cedar`, `alloy`, `ash`, `ballad`, `echo`, `fable`, `onyx`, `sage`, and `verse`. Voice character/accent quality varies; audition options before choosing a default.
5. Save settings and generate a short test narration.

Select the provider separately through `PUT /api/ai/media-settings` with `{"type":"tts","provider":"openai"}`. The OpenAI API key remains server-side in `OPENAI_API_KEY`; it is not returned by the settings API.

## Settings API

The existing `PUT /api/ai/config` endpoint now accepts the accent/style/speed fields:

```json
{
  "media": {
    "ttsModels": {
      "openai": "gpt-4o-mini-tts"
    },
    "ttsVoices": {
      "openai": "coral"
    },
    "ttsAccent": "Indian Hindi",
    "ttsStyle": "Warm, expressive storyteller",
    "ttsSpeed": 0.95
  }
}
```

`ttsSpeed` is clamped to the OpenAI-supported range of 0.25–4. `ttsAccent` and `ttsStyle` are descriptive controls used to compose the TTS `instructions` field. The Hindi-specific instructions are sent only for `gpt-4o-mini-tts`, because legacy `tts-1` / `tts-1-hd` models do not support that parameter.

## Important

This upload contains the **server** folder only, so this patch updates backend behavior and settings API data. The React client was not included; any new accent/style/speed controls must be added to the client Settings → Narration panel separately. Existing voice/provider/model controls continue to work.
