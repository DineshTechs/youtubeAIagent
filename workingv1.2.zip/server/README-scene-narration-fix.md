# Scene narration synchronization fix

The renderer requires one narration audio file per scene. The worker previously generated only one combined narration file, so rendering failed with:

`Scene narration audio set is incomplete (0/N).`

This fix now:
- generates TTS separately for every scene;
- validates every scene audio file with FFmpeg;
- measures each scene's actual audio duration;
- passes `sceneAudioFiles` and `sceneDurations` into the renderer;
- lets the renderer concatenate the validated scene audio in the same order as the scene images;
- reuses valid per-scene audio files on a retry instead of generating them again.

The existing FFmpeg-static path fix remains in place.
