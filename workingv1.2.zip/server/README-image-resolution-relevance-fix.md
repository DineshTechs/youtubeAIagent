# Scene image resolution + narration relevance fix

This build fixes two media-generation problems:

1. **No important scene cropping**
   - Every real scene image is normalized to the final Shorts canvas: **1080x1920 (9:16)**.
   - If the provider returns a different aspect ratio, the full image is preserved in the center.
   - A blurred extension of the same image fills the remaining canvas instead of cropping the subject.
   - Existing reusable scene assets are normalized too, so old generated assets do not keep the previous crop behavior.

2. **Images are tied to narration**
   - The image-generation prompt now includes the exact scene narration, the scene visual brief, on-screen-text context, recurring character descriptions, and series visual style.
   - The prompt explicitly requires the image to depict the specific subjects, action, objects, location, and emotion described by the narration.
   - Story generation prompts for Gemini, OpenAI-compatible providers (Groq/Cerebras), and OpenAI were strengthened so each `visualPrompt` must directly correspond to its scene narration.
   - Image prompts also require safe-center composition for a 1080x1920 Shorts frame and prohibit unrelated generic imagery.

3. **Pipeline Inspector**
   - Scene image traces now record both the generated image prompt and the original AI `visualPrompt`.
   - Scene media details record the normalized `1080x1920` resolution.

Restart both the API server and worker after replacing the project files. Existing videos are not automatically re-rendered; generate a new video (or resume a job that regenerates missing scene assets) to use the new image behavior.
