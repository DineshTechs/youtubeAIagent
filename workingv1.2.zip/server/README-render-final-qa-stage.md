# FFmpeg Render + Final QA stage

This patch hardens the FFMPEG_RENDER and FINAL_QA pipeline stages.

FFMPEG_RENDER now records the complete scene file list, audio/subtitle paths, output format and renderer metadata. FINAL_QA verifies the rendered file exists, is non-trivial in size, contains an MP4 `ftyp` header, and has a positive duration. The complete render result is retained in pipelineTrace output.
